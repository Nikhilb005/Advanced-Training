package Problem_Statement_12;

import java.util.*; 

public class Main {

	    static void printFirstRepeating(int arr[]) 
	    {  
	        int min = -1; 
	        HashSet<Integer> set = new HashSet<>(); 
	  
	        for (int i=arr.length-1; i>=0; i--) 
	        { 
	            if (set.contains(arr[i])) 
	                min = i; 
	            else 
	                set.add(arr[i]); 
	        } 
	  
	        if (min != -1) 
	          System.out.println("First Repeated Element is : " + arr[min]); 
	        else
	          System.out.println("There are no repeating elements"); 
	    } 
	   
	    public static void main (String[] args) throws java.lang.Exception 
	    { 
	        int arr[] = {1, 2, 3, 10, 2, 4, 5, 7, 8}; 
	        printFirstRepeating(arr); 
	    } 
	} 


